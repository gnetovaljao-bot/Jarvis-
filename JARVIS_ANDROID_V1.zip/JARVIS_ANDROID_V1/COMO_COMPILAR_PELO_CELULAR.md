# Como transformar em APK pelo celular

## 1. Crie uma conta no GitHub
Use o navegador do celular e crie/login em uma conta gratuita.

## 2. Crie um repositório
No GitHub, crie um repositório chamado `JARVIS`.

Pode deixar público. Não coloque senhas, tokens ou dados pessoais no código.

## 3. Envie os arquivos
Extraia o ZIP no celular e envie os arquivos do projeto para o repositório.

A estrutura precisa ficar assim:

JARVIS/
- app/
- gradle/
- .github/
- build.gradle
- settings.gradle
- gradle.properties

## 4. O GitHub compila sozinho
O arquivo `.github/workflows/build-apk.yml` inicia a compilação.

No repositório:
Actions → Build JARVIS APK → abra a execução → Artifacts → JARVIS-APK.

## 5. Instale
Baixe o ZIP do artifact, extraia e toque em `app-debug.apk`.

Se o Android bloquear, permita a instalação do aplicativo usado para baixar/abrir o APK nas configurações de "Instalar apps desconhecidos".

## Importante
Esta V1 é um protótipo funcional. Ela não usa uma API paga e não é um modelo de linguagem grande. O objetivo é criar a base Android para depois adicionar um cérebro mais avançado, memória melhor e skills.
