package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {

    LinearLayout chat;
    EditText input;
    TextView status;
    TextToSpeech tts;
    SharedPreferences memory;
    static final int REQ_AUDIO = 77;

    int cyan = 0xFF62D9FF;
    int bg = 0xFF080B12;
    int panel = 0xFF101722;
    int text = 0xFFEAF7FF;
    int muted = 0xFF8EA6B5;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        memory = getSharedPreferences("jarvis_memory", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        TextView title = new TextView(this);
        title.setText("JARVIS");
        title.setTextColor(cyan);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 28, 0, 10);

        status = new TextView(this);
        status.setText("● ONLINE");
        status.setTextColor(0xFF70FF9A);
        status.setGravity(Gravity.CENTER);
        status.setTextSize(13);

        ScrollView scroll = new ScrollView(this);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(18, 18, 18, 18);
        scroll.addView(chat);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setPadding(12, 10, 12, 14);
        bottom.setGravity(Gravity.CENTER_VERTICAL);

        input = new EditText(this);
        input.setHint("Fale com o JARVIS...");
        input.setHintTextColor(muted);
        input.setTextColor(text);
        input.setSingleLine(true);
        input.setBackgroundColor(panel);

        Button send = button("➤");
        Button mic = button("🎙");

        bottom.addView(input, new LinearLayout.LayoutParams(0, 58, 1));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(58, 58);
        bp.setMargins(8, 0, 0, 0);
        bottom.addView(mic, bp);
        bottom.addView(send, bp);

        root.addView(title);
        root.addView(status);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(bottom);

        setContentView(root);

        tts = new TextToSpeech(this, r -> {
            if (r == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("pt", "BR"));
            }
        });

        send.setOnClickListener(v -> process(input.getText().toString()));
        input.setOnEditorActionListener((v, a, e) -> {
            process(input.getText().toString());
            return true;
        });

        mic.setOnClickListener(v -> startVoice());

        addMessage("JARVIS", "Olá. Estou online. Digite ou toque no 🎙 para falar comigo.");
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(text);
        b.setTextSize(18);
        b.setBackgroundColor(panel);
        return b;
    }

    void addMessage(String who, String msg) {
        TextView v = new TextView(this);
        v.setText(who + "\n" + msg);
        v.setTextColor(text);
        v.setTextSize(16);
        v.setPadding(18, 14, 18, 14);
        v.setBackgroundColor(panel);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, 10);
        chat.addView(v, p);
    }

    void process(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) return;
        input.setText("");
        addMessage("VOCÊ", q);

        String a = answer(q);
        addMessage("JARVIS", a);
        speak(a);
    }

    String answer(String q) {
        String x = q.toLowerCase(Locale.ROOT);

        if (x.equals("sair") || x.equals("desligar")) {
            finish();
            return "Encerrando.";
        }

        if (x.equals("oi") || x.equals("olá") || x.equals("ola")) {
            return "Olá. JARVIS online. O que vamos fazer?";
        }

        if (x.contains("que horas") || x.equals("hora")) {
            return "Agora são " + new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()) + ".";
        }

        if (x.contains("qual a data") || x.contains("que dia")) {
            return "Hoje é " + new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date()) + ".";
        }

        if (x.contains("seu nome") || x.contains("quem é você")) {
            return "Eu sou o JARVIS, seu assistente pessoal.";
        }

        if (x.equals("ajuda") || x.equals("comandos")) {
            return "Posso conversar, falar, ouvir, guardar memórias e responder comandos básicos. Experimente: 'lembre que gosto de...'.";
        }

        if (x.startsWith("lembre que ")) {
            String value = q.substring(11).trim();
            memory.edit().putString("memory", value).apply();
            return "Certo. Guardei isso na minha memória local.";
        }

        if (x.contains("o que você lembra") || x.contains("o que lembra")) {
            String m = memory.getString("memory", "");
            return m.isEmpty() ? "Ainda não tenho uma memória salva." : "Eu lembro que: " + m;
        }

        if (x.equals("esqueça tudo") || x.equals("apague memória")) {
            memory.edit().clear().apply();
            return "Memória apagada.";
        }

        if (x.contains("bateria")) {
            return "Você pode ver a bateria do aparelho nas configurações rápidas. O acesso direto à bateria será uma das próximas skills.";
        }

        return "Entendi: " + q + ". Esta é a V1 do meu cérebro. Nas próximas versões vamos adicionar mais skills e inteligência.";
    }

    void speak(String s) {
        if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }

    void startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o JARVIS");

        try {
            startActivityForResult(i, 99);
        } catch (Exception e) {
            addMessage("JARVIS", "O reconhecimento de voz do Android não está disponível neste aparelho.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 99 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) process(r.get(0));
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
