# JARVIS V1 — Assistente pessoal para Android/Termux

Versão 1 feita para rodar no celular com Termux, priorizando custo R$0.

## O que já existe

- Conversa por texto
- Memória persistente em JSON
- Personalidade configurável
- Sistema de skills modular
- Comandos Android via Termux:API quando disponível
- Consulta de bateria
- Data e hora
- Abrir alguns apps/links
- Falar respostas com Text-to-Speech
- Ouvir usando Termux:API
- Histórico local
- Logs
- Instalador sem nano

## Requisitos

- Android
- Termux
- Python 3
- Opcional: Termux:API para microfone/TTS/recursos Android

## Instalação

No Termux:

```bash
cd ~/storage/downloads
unzip JARVIS_V1.zip -d JARVIS_V1
cd JARVIS_V1
bash instalar.sh
```

Depois:

```bash
cd ~/JARVIS_V1
bash iniciar.sh
```

Se você extrair em outro lugar, entre na pasta criada e execute `bash instalar.sh`.

## Comandos

- `ajuda`
- `oi`
- `que horas são`
- `qual a data`
- `bateria`
- `lembre que ...`
- `o que você lembra de mim`
- `esqueça tudo`
- `fale`
- `ouvir`
- `abrir youtube`
- `abrir chrome`
- `sair`

## Observação importante

A V1 possui um cérebro local de regras e memória. Isso permite funcionar sem pagar API. Ela não é um modelo gigante como ChatGPT: a próxima evolução será substituir/ampliar o cérebro por um modelo local ou outro backend gratuito, mantendo toda a estrutura criada aqui.
