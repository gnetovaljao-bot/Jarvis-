#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
python jarvis/jarvis.py
