#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "===================================="
echo "       JARVIS V1 - INSTALADOR"
echo "===================================="

pkg update -y
pkg install -y python unzip termux-api

echo
echo "[1/3] Criando diretórios..."
mkdir -p "$HOME/JARVIS_V1"
cp -r ./* "$HOME/JARVIS_V1/" 2>/dev/null || true

cd "$HOME/JARVIS_V1"

echo "[2/3] Ajustando permissões..."
chmod +x iniciar.sh
chmod +x jarvis/jarvis.py

echo "[3/3] Testando Python..."
python --version

echo
echo "===================================="
echo " INSTALAÇÃO CONCLUÍDA"
echo "===================================="
echo
echo "Para iniciar:"
echo "cd ~/JARVIS_V1 && bash iniciar.sh"
