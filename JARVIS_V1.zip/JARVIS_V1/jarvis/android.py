import shutil
import subprocess
import webbrowser

def has_cmd(name):
    return shutil.which(name) is not None

def run(cmd, timeout=15):
    try:
        return subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout
        )
    except Exception as e:
        return None

def battery():
    if not has_cmd("termux-battery-status"):
        return "O Termux:API não está disponível."
    r = run(["termux-battery-status"])
    if not r or r.returncode != 0:
        return "Não consegui consultar a bateria."
    try:
        import json
        d = json.loads(r.stdout)
        return (
            f"Bateria: {d.get('percentage', '?')}%. "
            f"Estado: {d.get('status', '?')}. "
            f"Temperatura: {d.get('temperature', '?')}°C."
        )
    except Exception:
        return r.stdout.strip()

def speak(text):
    if has_cmd("termux-tts-speak"):
        run(["termux-tts-speak", "-l", "pt-BR", text], timeout=30)
        return True
    return False

def listen(seconds=8):
    if not has_cmd("termux-speech-to-text"):
        return None, "O Termux:API não está disponível."
    r = run(["termux-speech-to-text"], timeout=max(20, seconds + 10))
    if not r or r.returncode != 0:
        return None, "Não consegui acessar o reconhecimento de voz."
    text = r.stdout.strip()
    return (text if text else None), None

def open_target(target):
    urls = {
        "youtube": "https://youtube.com",
        "google": "https://google.com",
        "chrome": "https://google.com",
        "discord": "https://discord.com/app",
        "whatsapp": "https://web.whatsapp.com",
        "github": "https://github.com"
    }
    url = urls.get(target.lower(), target if target.startswith("http") else None)
    if not url:
        return False
    try:
        webbrowser.open(url)
        return True
    except Exception:
        return False

def say_or_text(text, speak_enabled=False):
    if speak_enabled:
        speak(text)
    return text
