import re
from datetime import datetime
from .memory import memories, add_memory, clear_memory

class Brain:
    def __init__(self, config):
        self.config = config

    def answer(self, raw):
        text = raw.strip()
        low = text.lower()

        if not text:
            return "Não entendi."

        if low in {"sair", "exit", "quit", "desligar"}:
            return "__EXIT__"

        if low in {"ajuda", "help", "comandos"}:
            return (
                "Comandos: bateria, que horas são, qual a data, "
                "lembre que..., o que você lembra de mim, esqueça tudo, "
                "fale, ouvir, abrir youtube, abrir chrome e sair."
            )

        if low in {"oi", "olá", "ola", "e aí", "eai", "bom dia", "boa tarde", "boa noite"}:
            return "Olá. JARVIS online. O que vamos fazer?"

        if "que horas" in low or low == "hora":
            return "Agora são " + datetime.now().strftime("%H:%M:%S") + "."

        if "qual a data" in low or "que dia é hoje" in low or low == "data":
            return "Hoje é " + datetime.now().strftime("%d/%m/%Y") + "."

        if low.startswith("lembre que "):
            value = text[len("lembre que "):].strip()
            if value:
                add_memory(value, self.config.get("max_memory_items", 100))
                return "Certo. Vou guardar isso na minha memória local."
            return "O que você quer que eu lembre?"

        if low in {"o que você lembra de mim", "o que lembra de mim", "minhas memórias", "memórias"}:
            items = memories()
            if not items:
                return "Ainda não tenho memórias salvas."
            lines = [f"{i+1}. {x['text']}" for i, x in enumerate(items[-20:])]
            return "Estas são minhas memórias recentes:\n" + "\n".join(lines)

        if low in {"esqueça tudo", "apague minhas memórias", "apagar memória"}:
            clear_memory()
            return "Memória local apagada."

        if low == "fale":
            return "__SPEAK__"

        if low == "ouvir":
            return "__LISTEN__"

        if "seu nome" in low or "quem é você" in low:
            return "Eu sou o JARVIS V1, seu assistente pessoal local."

        if "como você funciona" in low:
            return (
                "Nesta V1, meu núcleo é local: eu interpreto comandos, "
                "uso memória JSON e posso chamar funções do Android pelo Termux."
            )

        return (
            "Entendi: " + text +
            ". Ainda estou na V1. Posso executar comandos básicos, "
            "usar minha memória e controlar funções disponíveis no Termux."
        )
