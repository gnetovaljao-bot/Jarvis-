#!/usr/bin/env python3
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from jarvis.brain import Brain
from jarvis.memory import save_message
from jarvis.android import battery, speak, listen, open_target

CONFIG_FILE = ROOT / "config.json"

def load_config():
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {
            "name": "JARVIS",
            "language": "pt-BR",
            "speak_by_default": False,
            "listen_seconds": 8,
            "max_memory_items": 100
        }

def handle_special(answer, config):
    if answer == "__SPEAK__":
        msg = "Teste de voz concluído. JARVIS está funcionando."
        ok = speak(msg)
        return "Falei a mensagem." if ok else "O TTS do Termux não está disponível."

    if answer == "__LISTEN__":
        text, err = listen(config.get("listen_seconds", 8))
        if err:
            return err
        return "Você disse: " + text if text else "Não consegui entender."

    return answer

def main():
    config = load_config()
    brain = Brain(config)

    print("=" * 44)
    print("             JARVIS V1")
    print("        Assistente local Android")
    print("=" * 44)
    print("Digite 'ajuda' para ver os comandos.")
    print("Digite 'sair' para encerrar.\n")

    while True:
        try:
            user = input("Você > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nJARVIS > Até mais.")
            break

        if not user:
            continue

        save_message("user", user)

        # Comandos Android que precisam de ação externa ao cérebro
        low = user.lower()

        if low == "bateria" or "nível da bateria" in low:
            answer = battery()
        elif low.startswith("abrir "):
            target = user[6:].strip()
            if open_target(target):
                answer = f"Abrindo {target}."
            else:
                answer = "Ainda não sei abrir esse destino."
        else:
            answer = brain.answer(user)

        if answer == "__EXIT__":
            print("JARVIS > Encerrando. Até mais.")
            break

        answer = handle_special(answer, config)
        save_message("assistant", answer)

        print("JARVIS >", answer)

        if config.get("speak_by_default") and not answer.startswith("O Termux"):
            speak(answer)

if __name__ == "__main__":
    main()
