import json
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data"
MEMORY_FILE = DATA / "memory.json"
HISTORY_FILE = DATA / "history.json"

def _load(path, default):
    DATA.mkdir(exist_ok=True)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def _save(path, data):
    DATA.mkdir(exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def memories():
    return _load(MEMORY_FILE, [])

def add_memory(text, limit=100):
    items = memories()
    item = {
        "text": text.strip(),
        "created_at": datetime.now().isoformat(timespec="seconds")
    }
    items.append(item)
    items = items[-limit:]
    _save(MEMORY_FILE, items)

def clear_memory():
    _save(MEMORY_FILE, [])

def save_message(role, text):
    history = _load(HISTORY_FILE, [])
    history.append({
        "role": role,
        "text": text,
        "created_at": datetime.now().isoformat(timespec="seconds")
    })
    _save(HISTORY_FILE, history[-300:])
