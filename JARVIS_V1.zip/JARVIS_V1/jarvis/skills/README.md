# Skills

Esta pasta será usada para adicionar funções novas ao JARVIS sem precisar reescrever o núcleo.

Exemplos para as próximas versões:
- clima
- música
- calendário
- Gmail
- Discord
- pesquisas
- automações
- controle de outros aplicativos

A V1 mantém a arquitetura modular para essas extensões.
