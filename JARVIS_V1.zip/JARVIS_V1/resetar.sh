#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"

echo "Isso apagará a memória e o histórico do JARVIS."
printf "Digite APAGAR para confirmar: "
read confirm

if [ "$confirm" = "APAGAR" ]; then
  rm -f data/memory.json data/history.json
  echo "Memória e histórico apagados."
else
  echo "Cancelado."
fi
